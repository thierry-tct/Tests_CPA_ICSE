#!/usr/bin/perl
# Test tail.

# Copyright (C) 2008-2011 Free Software Foundation, Inc.

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

use strict;

my $prog = 'tail';
my $normalize_filename = {ERR_SUBST => 's/^$prog: .*?:/$prog: -:/'};

# Turn off localization of executable's output.
@ENV{qw(LANGUAGE LANG LC_ALL)} = ('C') x 3;

my @tv = (
['n-5',  '-n -0', "y\n" x 5, '', 0],
);

my @Tests;

foreach my $t (@tv)
  {
    my ($test_name, $flags, $in, $exp, $ret, $err_msg) = @$t;
    my $e = [$test_name, $flags, {IN=>$in}, {OUT=>$exp}];
    $ret
      and push @$e, {EXIT=>$ret}, {ERR=>$err_msg};

    $test_name =~ /^(obs-plus-|minus-)/
      and push @$e, {ENV=>'_POSIX2_VERSION=199209'};

    $test_name =~ /^(err-6|c-2)$/
      and push @$e, {ENV=>'_POSIX2_VERSION=200112'};

    $test_name =~ /^f-pipe-/
      and push @$e, {ENV=>'POSIXLY_CORRECT=1'};

    push @Tests, $e;
  }

@Tests = triple_test \@Tests;

# If you run the minus* tests with a FILE arg they'd hang.
# If you run the err-1 or err-3 tests with a FILE, they'd misinterpret
# the arg unless we are using the obsolete form.
@Tests = grep { $_->[0] !~ /^(minus|err-[13])/ || $_->[0] =~ /\.[rp]$/ } @Tests;

# Using redirection or a file would make this hang.
@Tests = grep { $_->[0] !~ /^f-/ || $_->[0] =~ /\.p$/ } @Tests;

my $save_temps = $ENV{DEBUG};
my $verbose = $ENV{VERBOSE};

my $fail = run_tests ($prog, $prog, \@Tests, $save_temps, $verbose);
exit $fail;

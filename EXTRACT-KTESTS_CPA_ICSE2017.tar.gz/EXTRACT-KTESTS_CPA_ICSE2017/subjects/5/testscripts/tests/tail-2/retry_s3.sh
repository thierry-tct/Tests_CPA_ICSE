#!/bin/sh
# Exercise tail's behavior regarding missing files with/without --retry.

# Copyright (C) 2013 Free Software Foundation, Inc.

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

. "${srcdir=.}/tests/init.sh"; path_prepend_ ./src
print_ver_ tail

# Function to check the expected line count in 'out'.
# Called via retry_delay_().  Sleep some time - see retry_delay_() - if the
# line count is still smaller than expected.
ExpLineCount=""
wait4lines_ ()
{
  local delay=$1
  local elc=${2:-$ExpLineCount}   # Expected line count.
  [ $( wc -l < out ) -ge $elc ] || { sleep $delay; return 1; }
}


# === Test:
# Ensure that "tail --retry --follow=name" waits for the file to appear.
 timeout -s INT "${MFIFOR_KLEE_NO_TIMEOUT:-10}" tail -s.1 --follow=name --retry missing >out 2>&1 & pid=$!
  ExpLineCount=1
retry_delay_ wait4lines_ .1 6 1 || fail=1  # Wait for "cannot open" error.
echo "X" > missing              || fail=1  # Write "X" into 'missing'.
 ExpLineCount=3
retry_delay_ wait4lines_ .1 6 3 || fail=1  # Wait for the expected output.
 [ "${MFIFOR_KLEE_NO_TIMEOUT:-}" != "" ] || kill -s HUP $pid
wait $pid
# Expect 3 lines in the output file.
[ $( wc -l < out ) = 3 ]            || { fail=1; cat out; }
grep -F 'cannot open' out           || { fail=1; cat out; }
grep -F 'has become accessible' out || { fail=1; cat out; }
grep '^X$' out                      || { fail=1; cat out; }
rm -f missing out                   || fail=1


Exit $fail

#!/bin/bash
# Build script for (1) tail
#Note: Make sure that here, all used tool are refered with absolute path (to avoid a control command to be considered as a test)
set -u
error_exit()
{
    /bin/echo $1
    exit 1
}

[ $# = 3 ] || error_exit "Error: build script expected 3 parameters, $# provided: <$0> <compiler> <CFLAGS> <mode: [ build(make distclean,bootstrap, config, make); clean-make(make clean, make); make]>"
COMPILER=$1
CFLAGS=$2
MODE=$3
rootDir=$MFI_ROOTDIR

calldir=`/bin/pwd`
cd $rootDir

/bin/rm -f $MFI_EXEDIR/$MFI_PROGRAM

#Avoid unsuported inline asm error of llvm-gcc by setting __GNUC__ value to less than 2 so that bits/select.h will use non asm for FD_ZERO definition
if [ $COMPILER = "wllvm" ] || echo "$CFLAGS" | grep "\-E -P"  > /dev/null
then
    #prepend
    grep "^#define __MFI_REAL_GNUC__" src/tail.c > /dev/null || \
                sed -i '1s/^/#define __MFI_REAL_GNUC__  __GNUC__\n#undef __GNUC__\n#define __GNUC__   1\n/'  src/tail.c || error_exit "Failed to replace src/tail.c's included 'select.h'"
fi

if [ "$MODE" = "build" ]
then
    make clean-generic ; rm -f  src/*.o ; make distclean #|| ./bootstrap --skip-po || error_exit "Error: make distclean failed. (in $0)"
    ./configure --disable-nls CC=$COMPILER CFLAGS="-Wno-error -std=c99 $CFLAGS -Wno-error" #|| error_exit "Error: configure failed. (in $0)"
    configstatus=$?
    make --just-print
    if [ $? != 0 -o $configstatus != 0 ]
    then 
        make distclean ; ./bootstrap --skip-po || error_exit "Error: bootstrap failed. (in $0)"
        ./configure --disable-nls CC=$COMPILER CFLAGS="-Wno-error -std=c99 $CFLAGS -Wno-error" || error_exit "Error: configure failed. (in $0)"
    fi
    #repair Makefile...
    #sed -i 's|run_help2man = $(PERL) -- $(srcdir)/man/help2man|run_help2man = $(PERL) -- $(srcdir)/man/help2man --no-discard-stderr|g' Makefile
    echo "all: ;" > doc/Makefile
    echo "all: ;" > po/Makefile
    make CC=$COMPILER CFLAGS="-Wno-error -std=c99 $CFLAGS -Wno-error" #|| error_exit "Error: make failed. (in $0)"
elif [ "$MODE" = "clean-make" ]
then
    make clean-generic ; rm -f  src/*.o #|| error_exit "Error: make clean failed. (clean-make in $0)"
    make CC=$COMPILER CFLAGS="-std=c99 $CFLAGS -Wno-error" #|| error_exit "Error: make failed. (in $0)"
elif [ "$MODE" = "make" ]
then
    make CC=$COMPILER CFLAGS="-std=c99 $CFLAGS -Wno-error" src/tail #-std=gnu99 || error_exit "Error: make failed. (in $0)"
else
    error_exit "Error: Wrong build mode: $MODE. (in $0)"
fi

if [ $COMPILER = "wllvm" ] || echo "$CFLAGS" | grep "\-E -P" > /dev/null
then
    #remove prepended
    if grep "^#define __MFI_REAL_GNUC__" src/tail.c > /dev/null 
    then
        sed -i '1,3d' src/tail.c || error_exit "Failed to replace src/tail.c's included 'select.h'"
    fi
fi

cd $calldir

# *** wllvm can't generate BC when the extension is not .o, .so,...
### $COMPILER $CFLAGS -c `dirname $0`/src/main.c -o `dirname $0`/src/main.o	#Compile	

### $COMPILER $CFLAGS -o `dirname $0`/src/mainT `dirname $0`/src/main.o	#link


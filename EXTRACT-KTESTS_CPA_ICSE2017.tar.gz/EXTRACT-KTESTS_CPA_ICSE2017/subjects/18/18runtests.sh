#!/bin/bash

#Note: Make sure that here, all used tool are refered with absolute path (to avoid a control command to be considered as a test)

set -u
error_exit()
{
    /bin/echo $1
    exit 3
}

[ $# = 1 ] || error_exit "Error: runtest script expected 1 parameter, $# provided: <$0> <test name>"

TC=$1

/usr/bin/test -f $MFI_EXEDIR/$MFI_PROGRAM || error_exit "Error: Could not find executable $MFI_PROGRAM"
rootDir=$MFI_ROOTDIR 
testcaseDir="tests/misc"       #change here

#optimization of running time
# exit with code:
# 255 , when the optimization is enabled here, and the optimized run succeed
# 254 , when the optimization is enabled here, but the optimized run failed
if /bin/echo $TC | /bin/grep '\*\*MFI\*\*OPTIMIZE\*\*' > /dev/null
then
    exit 1 #error_exit "wrong test"
    tmptc="$(/bin/mktemp).sh"
    /bin/mv ${tmptc%.sh} $tmptc
    /bin/chmod +x "$tmptc"
    /bin/echo "#! /bin/bash" > $tmptc
    /bin/echo "export MFIKTESTSREPLAY_USER_SET_MAXTIMEOUT=15" >> $tmptc
    /bin/echo $TC | /bin/sed 's/\*\*MFI\*\*OPTIMIZE\*\*//g' >> $tmptc
    cd $rootDir/$testcaseDir
    /bin/echo "Replaying ktests..."
    returnCode=255   #This show that optimize is supported and was run sucessfully
    
    #For perl, copy the test executer that skip post test processing
    if [ -f ../Coreutils.pm-MFIOPT ]; then mv ../Coreutils.pm ../Coreutils.pm-BAk; mv ../Coreutils.pm-MFIOPT ../Coreutils.pm; fi
    
     /usr/bin/make -i check-TESTS TESTS="$tmptc" VERBOSE=no > $tmptc.makeout || returnCode=254 
    
    #For perl, restaure test executer 
    if [ -f ../Coreutils.pm-BAK ]; then mv ../Coreutils.pm ../Coreutils.pm-MFIOPT; mv ../Coreutils.pm-BAK ../Coreutils.pm; fi
    
    /bin/grep "^ All 1 tests passed" $tmptc.makeout || returnCode=254 
    cd - > /dev/null
    /bin/rm -f $tmptc ${tmptc%.sh}.log ${tmptc%.sh}.trs $tmptc.makeout
    exit $returnCode
    #when 
fi        
 
cd $rootDir/$testcaseDir

export RUN_VERY_EXPENSIVE_TESTS=yes
export RUN_EXPENSIVE_TESTS=yes

fail=0
isverbose=""
[ "$TC" = "seq_s1" ] && isverbose=yes
/bin/rm -rf gt-* 

    if [ "${MFIOPT_KTESTSREPLAY_OPTIMIZER:-off}" = "on" ]
    then
        VERBOSE=$isverbose  /bin/bash ./$TC > /dev/null 2>&1 || fail=1 
    else
         /usr/bin/make -i check-TESTS TESTS="$TC" VERBOSE=$isverbose | /bin/grep "PASS: $TC" > /dev/null 2>&1 || fail=1 
        rm -rf ${TC%.}.log ${TC%.}.trs  tmp*
    fi
/bin/rm -rf $(dirname $TC)/*.log $(dirname $TC)/*.trs  *.temps .*.temps
 /bin/rm -rf gt-*  

cd - > /dev/null

exit $fail

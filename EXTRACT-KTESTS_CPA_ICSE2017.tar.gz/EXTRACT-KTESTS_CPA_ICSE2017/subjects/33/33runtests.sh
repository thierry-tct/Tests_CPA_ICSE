#!/bin/bash

#Note: Make sure that here, all used tool are refered with absolute path (to avoid a control command to be considered as a test)

set -u
error_exit()
{
    /bin/echo $1
    exit 3
}

[ $# = 1 ] || error_exit "Error: runtest script expected 1 parameter, $# provided: <$0> <test name>"

TC=$1

/usr/bin/test -f $MFI_EXEDIR/$MFI_PROGRAM || error_exit "Error: Could not find executable $MFI_PROGRAM"
rootDir=$MFI_ROOTDIR 

#optimization of running time
# exit with code:
# 255 , when the optimization is enabled here, and the optimized run succeed
# 254 , when the optimization is enabled here, but the optimized run failed
if /bin/echo $TC | /bin/grep '\*\*MFI\*\*OPTIMIZE\*\*' > /dev/null
then
    # do not need optimization 
    exit 1
fi        
 
testcaseDir="find/testsuite"       #change here

cd $rootDir/$testcaseDir

export RUN_VERY_EXPENSIVE_TESTS=yes
export RUN_EXPENSIVE_TESTS=yes

fail=0

if [ "$TC" = "regression.sh" -o "${TC: -3}" = ".sh" ]
then
      ./$TC $rootDir > /dev/null || fail=1
    cd - > /dev/null
    exit $fail
fi

TCexp=${TC%.*}.exp
tcsuff=${TC#*.}
if echo "$tcsuff" | grep "\-O[0-3]$" > /dev/null
then
    oo="${tcsuff#*-O}"
    sed -i -E "s/OPTIMISATION_LEVELS \{[^{}]*\}/OPTIMISATION_LEVELS {$oo}/g" site.exp  || error_exit "Error: Failed to set test's corresponding 'OPTIMISATION_LEVELS' var"
fi

[ "${EKLEEPSE_REPLAY_TIMEOUT:-}" != "" ] && [ $EKLEEPSE_REPLAY_TIMEOUT -gt 3 ] && export EKLEEPSE_REPLAY_TIMEOUT=3

  runtest --tool find script.exp $TCexp > /dev/null  
grep "^PASS: $TC" find.sum > /dev/null || fail=1

cd - > /dev/null

exit $fail

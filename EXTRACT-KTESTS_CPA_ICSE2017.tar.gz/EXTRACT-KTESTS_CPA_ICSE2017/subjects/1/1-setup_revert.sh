#! /bin/bash

## This script set up the project to run the tests, it also restore as initial.

error_exit()
{
    echo "setup_revert failure: $1"
    exit 1
}

[ $# = 2 ] || error_exit "Expected 2 arguments, $# passed.  $0 <mode [setup, revert]> <rootdir>"

mode=$1
rootDir=$2

TopDir=$(readlink -f $(dirname $0))

if [ "$mode" = "setup" ]
then
    if ! test -d $rootDir/MYDATA.bak.bak
    then
        { test -d $rootDir/MYDATA && mv $rootDir/MYDATA $rootDir/MYDATA.bak.bak ; } || error_exit "failed to backup MYDATA"
    fi
    rm -rf $rootDir/MYDATA
    cp -rf $TopDir/testscripts/MYDATA $rootDir || error_exit "failed to copy physical tests scripts"
elif [ "$mode" = "revert" ]
then
    if test -d $rootDir/MYDATA.bak.bak
    then
        rm -rf $rootDir/MYDATA || error_exit "failed to removed physical tests scripts"
        mv $rootDir/MYDATA.bak.bak $rootDir/MYDATA || error_exit "Failed to restore MYDATA"
    fi
else
    error_exit "Invalid mode"
fi

#!/bin/sh
# Test the -I option added to coreutils 6.0

# Copyright (C) 2006-2016 Free Software Foundation, Inc.

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

########################### TCT changed path

. "${srcdir=.}/MYDATA/TESTS/init.sh"; 
print_ver_ rm

mkdir -p dir1-1 dir2-1 dir2-2 || framework_failure_
touch file1-1 file2-1 file2-2 file2-3 file3-1 file3-2 file3-3 file3-4 \
  || framework_failure_
echo y > in-y || framework_failure_
echo n > in-n || framework_failure_


echo 'one file, recursion, answer no' >> err || framework_failure_
 rm -I -R dir1-* < in-n >> out 2>> err || fail=1
echo . >> err || fail=1
test -d dir1-1 || fail=1


cat <<\EOF > expout || fail=1
EOF
cat <<EOF > experr || fail=1
one file, recursion, answer no
rm: remove 1 argument recursively? .
EOF

compare expout out || fail=1
compare experr err || fail=1

Exit $fail

failures=0
status=`echo '3252'| { LC_ALL=ru_RU.KOI8-R   $1/grep -E -e '[0-9]' >/dev/null 2>&1 ; echo $?; }`
if test $status -ne 0 ; then
echo Spencer test \#76 failed \(zh_CN\)
failures=1
fi
exit $failures

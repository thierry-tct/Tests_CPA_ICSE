failures=0
status=`echo 'zzzzz'| { LC_ALL=ru_RU.KOI8-R   $1/grep -E -e 'zzz[a-z]$' >/dev/null 2>&1 ; echo $?; }`
if test $status -ne 0 ; then
echo Spencer test \#46 failed \(ru_RU.KOI8-R\)
failures=1
fi
exit $failures

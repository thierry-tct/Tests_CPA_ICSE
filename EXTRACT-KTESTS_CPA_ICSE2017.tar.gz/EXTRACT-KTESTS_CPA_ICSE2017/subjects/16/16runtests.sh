#!/bin/bash

#Note: Make sure that here, all used tool are refered with absolute path (to avoid a control command to be considered as a test)

set -u
error_exit()
{
    /bin/echo $1
    exit 3
}

[ $# = 1 ] || error_exit "Error: runtest script expected 1 parameter, $# provided: <$0> <test name>"

TC=$1

/usr/bin/test -f $MFI_EXEDIR/$MFI_PROGRAM || error_exit "Error: Could not find executable $MFI_PROGRAM"
rootDir=$MFI_ROOTDIR 

#optimization of running time
# exit with code:
# 255 , when the optimization is enabled here, and the optimized run succeed
# 254 , when the optimization is enabled here, but the optimized run failed
if /bin/echo $TC | /bin/grep '\*\*MFI\*\*OPTIMIZE\*\*' > /dev/null
then
#exit 1 #error_exit "wrong test"
    cd $rootDir/"tests"
    tmptc="mfi_ktest-replay-optimizer"
    /bin/echo "#! /bin/bash" > $tmptc
    /bin/echo "export MFIKTESTSREPLAY_USER_SET_MAXTIMEOUT=15" >> $tmptc
    /bin/echo $TC | /bin/sed 's/\*\*MFI\*\*OPTIMIZE\*\*//g' >> $tmptc
    /bin/chmod +x "$tmptc"
    /bin/echo "Replaying ktest s..."
    returnCode=255   #This show that optimize is supported and was run sucessfully
     /usr/bin/make -i check-TESTS TESTS="$tmptc" VERBOSE=no > $tmptc.makeout || returnCode=254 
    /bin/grep "^# PASS:  1" $tmptc.makeout || returnCode=254 
    /bin/rm -f $tmptc ${tmptc}.log ${tmptc}.trs $tmptc.makeout
    cd - > /dev/null
    exit $returnCode
    #when 
fi        
 
#testcaseDir="misc"       #change here

 [ "${EKLEEPSE_RUN_SELECTIVE:-}" != "" ] &&  /bin/echo "$TC" | /bin/grep "/manuallyAddedMFI/" > /dev/null && exit 0; 

cd $rootDir/"tests"

export RUN_VERY_EXPENSIVE_TESTS=yes
export RUN_EXPENSIVE_TESTS=yes

if [ "${EKLEEPSE_RUN_SELECTIVE:-}" = "1" ] || [ "${EKLEEPSE_REPLAY_MAXTIMEOUT:-}" != "" ]
then
    export MFIFOR_KLEE_NO_TIMEOUT=9999999
fi

fail=0
isverbose=""
[ "$TC" = "misc/tail_s1" ] && isverbose=yes
/bin/rm -rf gt-* 
/bin/grep `/usr/bin/basename $TC` "tail-2/root/testcaselist.txt" > /dev/null    #change here
if [ $? = 0 ]                   
then    
    if [ "${MFIOPT_KTESTSREPLAY_OPTIMIZER:-off}" = "on" ]
    then
        VERBOSE=$isverbose sudo -E /bin/bash ./shell-or-perl --test-name "$TC" --srcdir "." --shell "/bin/bash" --perl "perl" -- "./$TC" > /dev/null 2>&1 || fail=1 
        #VERBOSE=$isverbose sudo -E  ./$TC > /dev/null 2>&1 || fail=1
    else
        sudo -E  /usr/bin/make -i check-TESTS TESTS="$TC" VERBOSE=$isverbose | /bin/grep "PASS: $TC" > /dev/null || fail=1 
        sudo /bin/rm -rf ${TC}.log ${TC}.trs  tmp* *.temps .*.temps
    fi
else
    if [ "${MFIOPT_KTESTSREPLAY_OPTIMIZER:-off}" = "on" ]
    then
        VERBOSE=$isverbose /bin/bash ./shell-or-perl --test-name "$TC" --srcdir "." --shell "/bin/bash" --perl "perl" -- "./$TC" > /dev/null 2>&1 || fail=1 
        #[ "/usr/bin/dirname $TC" = "tail-2" ] && VERBOSE=$isverbose  ./$TC > /dev/null || fail=1
        #[ "/usr/bin/dirname $TC" = "misc" ] && VERBOSE=$isverbose  /usr/bin/perl -w -I. -MCoreutils -MCuSkip -M"CuTmpdir ./$TC" > /dev/null 2>&1 || fail=1 
    else
         /usr/bin/make -i check-TESTS TESTS="$TC" VERBOSE=$isverbose | /bin/grep "PASS: $TC" > /dev/null || fail=1 
        /bin/rm -rf ${TC}.log ${TC}.trs  tmp* *.temps .*.temps
    fi
fi
 /bin/rm -rf gt-*  

cd - > /dev/null

exit $fail

#!/bin/sh
# Test some of cp's options and how cp handles situations in
# which a naive implementation might overwrite the source file.

# Copyright (C) 1998-2012 Free Software Foundation, Inc.

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

. "${srcdir=.}/tests/init.sh"; path_prepend_ ./src
print_ver_ cp

# Unset CDPATH.  Otherwise, output from the 'cd dir' command
# can make this test fail.
(unset CDPATH) >/dev/null 2>&1 && unset CDPATH

VERSION_CONTROL=numbered; export VERSION_CONTROL

# Determine whether a hard link to a symlink points to the symlink
# itself or to its referent.  For example, the link from FreeBSD6.1
# does dereference a symlink, but the one from Linux does not.
ln -s no-such dangling-slink
ln dangling-slink hard-link > /dev/null 2>&1 \
  && hard_link_to_symlink_does_the_deref=no \
  || hard_link_to_symlink_does_the_deref=yes
rm -f no-such dangling-slink hard-link

test $hard_link_to_symlink_does_the_deref = yes \
    && remove_these_sed='/^0 -[bf]*l .*sl1 ->/d' \
    || remove_these_sed='/^ELIDE NO TEST OUTPUT/d'

exec 3>&1 1> actual

# FIXME: This should be bigger: like more than 8k
contents=XYZ

for args in 'sl1 sl2'; do
  for options in ''; do
    case $args$options in
      # These tests are not portable.
      # They all involve making a hard link to a symbolic link.
      # In the past, we've skipped the tests that are not portable,
      # by doing "continue" here and eliminating the corresponding
      # expected output lines below.  Don't do that anymore.
      'symlink foo'-dfl)
        continue;;
      'symlink foo'-bdl)
        continue;;
      'symlink foo'-bdfl)
        continue;;
      'sl1 sl2'-dfl)
        continue;;
      'sl1 sl2'-bd*l)
        continue;;
      'sl1 sl2'-dl)
        continue;;
    esac

    # cont'd  Instead, skip them only on systems for which link does
    # dereference a symlink.  Detect and skip such tests here.
    case $hard_link_to_symlink_does_the_deref:$args:$options in
      'yes:sl1 sl2:-fl')
        continue ;;
      'yes:sl1 sl2:-bl')
        continue ;;
      'yes:sl1 sl2:-bfl')
        continue ;;
    esac

    rm -rf dir
    mkdir dir
    cd dir
    echo $contents > foo
    case "$args" in *symlink*) ln -s foo symlink ;; esac
    case "$args" in *hardlink*) ln foo hardlink ;; esac
    case "$args" in *sl1*) ln -s foo sl1;; esac
    case "$args" in *sl2*) ln -s foo sl2;; esac
    (
      (
        # echo 1>&2 cp $options $args
         cp $options $args 2>_err
        echo $? $options

        # Normalize the program name and diagnostics in the error output,
        # and put brackets around the output.
        if test -s _err; then
          sed '
            s/^[^:]*:\([^:]*\).*/cp:\1/
            1s/^/[/
            $s/$/]/
          ' _err
        fi
        # Strip off all but the file names.
        ls=$(ls -gG --ignore=_err . \
             | sed \
                -e '/^total /d' \
                -e 's/^[^ ]*  *[^ ]*  *[^ ]*  *[^ ]*  *[^ ]*  *[^ ]*  *//')
        echo "($ls)"
        # Make sure the original is unchanged and that
        # the destination is a copy.
        for f in $args; do
          if test -f $f; then
            case "$(cat $f)" in
              "$contents") ;;
              *) echo cp FAILED;;
            esac
          else
            echo symlink-loop
          fi
        done
      ) | tr '\n' ' '
      echo
    ) | sed 's/  *$//'
    cd ..
  done
  echo
done

cat <<\EOF | sed "$remove_these_sed" > expected
1 [cp: 'sl1' and 'sl2' are the same file] (foo sl1 -> foo sl2 -> foo)

EOF

exec 1>&3 3>&-

compare expected actual 1>&2 || fail=1

Exit $fail

#!/bin/sh
# Test basic --backup functionality for both cp and mv.

# Copyright (C) 1999-2012 Free Software Foundation, Inc.

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

. "${srcdir=.}/tests/init.sh"; path_prepend_ ./src
print_ver_ cp

umask 022

# Be careful to close $actual before removing the containing directory.
# Use '1>&2' rather than '1<&-' since the latter appears not to work
# with /bin/sh from powerpc-ibm-aix4.2.0.0.

actual=actual
expected=expected

exec 3>&1 1> $actual

for initial_files in 'x y'; do
  for opt in off; do
    touch $initial_files
       cp --backup=$opt x y || fail=1
    echo $initial_files $opt: $(ls [xy]*); rm -f x y y~ y.~?~
  done
done




cat <<\EOF > $expected-tmp
x y off: x y
EOF

#sed 's/: x/:/' $expected-tmp |cat $expected-tmp - > $expected

#exec 1>&3 3>&-

compare $expected-tmp $actual || fail=1

Exit $fail

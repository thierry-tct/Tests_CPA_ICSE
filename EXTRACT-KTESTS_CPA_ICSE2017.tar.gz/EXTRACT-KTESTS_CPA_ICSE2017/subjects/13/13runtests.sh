#!/bin/bash

#Note: Make sure that here, all used tool are refered with absolute path (to avoid a control command to be considered as a test)

set -u
error_exit()
{
    /bin/echo $1
    exit 3
}

[ $# = 1 ] || error_exit "Error: runtest script expected 1 parameter, $# provided: <$0> <test name>"

TC=$1

/usr/bin/test -f $MFI_EXEDIR/$MFI_PROGRAM || error_exit "Error: Could not find executable $MFI_PROGRAM"
rootDir=$MFI_ROOTDIR 

#optimization of running time
# exit with code:
# 255 , when the optimization is enabled here, and the optimized run succeed
# 254 , when the optimization is enabled here, but the optimized run failed
if /bin/echo $TC | /bin/grep '\*\*MFI\*\*OPTIMIZE\*\*' > /dev/null
then
#error_exit "wrong test"
    tmptc="$(/bin/mktemp).sh"
    /bin/mv ${tmptc%.sh} $tmptc
    /bin/chmod +x "$tmptc"
    /bin/echo "#! /bin/bash" > $tmptc
    /bin/echo "export MFIKTESTSREPLAY_USER_SET_MAXTIMEOUT=15" >> $tmptc
    /bin/echo $TC | /bin/sed 's/\*\*MFI\*\*OPTIMIZE\*\*//g' >> $tmptc
    cd $rootDir
    /bin/echo "Replaying ktests..."
    returnCode=255   #This show that optimize is supported and was run sucessfully
     /usr/bin/make -i check-TESTS TESTS="$tmptc" VERBOSE=no > $tmptc.makeout || returnCode=254 
    /bin/grep "^# PASS:  1" $tmptc.makeout || returnCode=254 
    cd - > /dev/null
    /bin/rm -f $tmptc ${tmptc%.sh}.log ${tmptc%.sh}.trs $tmptc.makeout
    exit $returnCode
    #when 
fi        
 
#testcaseDir="tests/misc"       #change here

cd $rootDir

export RUN_VERY_EXPENSIVE_TESTS=yes
export RUN_EXPENSIVE_TESTS=yes

fail=0
isverbose=""
[ "$TC" = "tests/ls/abmon-align_s10.sh" ] && isverbose=yes
sudo /bin/rm -rf gt-* 
/bin/grep `/usr/bin/basename $TC` "tests/ls/root/testcaselist.txt" > /dev/null    #change here
if [ $? = 0 ]                   
then
    if [ "${MFIOPT_KTESTSREPLAY_OPTIMIZER:-off}" = "on" ]
    then
        VERBOSE=$isverbose sudo -E  /bin/bash ./$TC > /dev/null 2>&1 || fail=1
    else
        sudo -E  /usr/bin/make -i check-TESTS TESTS="$TC" VERBOSE=$isverbose | /bin/grep "PASS: $TC" > /dev/null || fail=1 
        sudo /bin/rm -rf ${TC%.}.log ${TC%.}.trs  $(/usr/bin/dirname $TC)/*.temps
    fi
else
    if [ "${MFIOPT_KTESTSREPLAY_OPTIMIZER:-off}" = "on" ]
    then
        [ "${TC: -3}" = ".sh" ] && VERBOSE=$isverbose  /bin/bash ./$TC > /dev/null 2>&1 || fail=1 
        [ "${TC: -3}" = ".pl" ] && VERBOSE=$isverbose  /usr/bin/perl -w -I./tests -MCoreutils -MCuSkip -MCuTmpdir ./$TC > /dev/null 2>&1 || fail=1 
    else
         /usr/bin/make -i check-TESTS TESTS="$TC" VERBOSE=$isverbose | /bin/grep "PASS: $TC" > /dev/null || fail=1 
        /bin/rm -rf ${TC%.}.log ${TC%.}.trs  $(/usr/bin/dirname $TC)/*.temps
    fi
fi
sudo /bin/rm -rf $(dirname $TC)/*.log $(dirname $TC)/*.trs  $(/usr/bin/dirname $TC)/*.temps .*.temps
sudo /bin/rm -rf gt-*  

cd - > /dev/null

exit $fail

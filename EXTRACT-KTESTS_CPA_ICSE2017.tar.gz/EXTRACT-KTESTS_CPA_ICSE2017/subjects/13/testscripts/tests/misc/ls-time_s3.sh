#!/bin/sh
# Test some of ls's sorting options.

# Copyright (C) 1998-2012 Free Software Foundation, Inc.

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

. "${srcdir=.}/tests/init.sh"; path_prepend_ ./src
print_ver_ ls

# Avoid any possible glitches due to daylight-saving changes near the
# time stamps used during the test.
TZ=UTC0
export TZ

t1='1998-01-15 21:00'
t2='1998-01-15 22:00'
t3='1998-01-15 23:00'

u1='1998-01-14 11:00'
u2='1998-01-14 12:00'
u3='1998-01-14 13:00'

touch -m -d "$t3" a || framework_failure_
touch -m -d "$t2" b || framework_failure_
touch -m -d "$t1" c || framework_failure_

touch -a -d "$u3" c || framework_failure_
touch -a -d "$u2" b || framework_failure_
# Make sure A has ctime at least 1 second more recent than C's.
sleep 2
touch -a -d "$u1" a || framework_failure_
# Updating the atime is usually enough to update the ctime, but on
# Solaris 10's tmpfs, ctime is not updated, so force an update here:
{ ln a a-ctime && rm a-ctime; } || framework_failure_


# Sleep so long in an attempt to avoid spurious failures
# due to NFS caching and/or clock skew.
sleep 2

# Create a link, updating c's ctime.
ln c d || framework_failure_

# Before we go any further, verify that touch's -m option works.
set -- $( ls --full -l a)
case "$*" in
  *" $t3:00.000000000 +0000 a") ;;
  *)
  # This might be what's making HPUX 11 systems fail this test.
  cat >&2 << EOF
A basic test of touch -m has just failed, so the subsequent
tests in this file will not be run.

In the output below, the date of last modification for 'a' should
have been $t3.
EOF
   ls --full -l a
  framework_failure_
  ;;
esac

# Ensure that touch's -a option works.
set -- $( ls --full -lu a)
case "$*" in
  *" $u1:00.000000000 +0000 a") ;;
  *)
  # This might be what's making HPUX 11 systems fail this test.
  cat >&2 << EOF
A fundamental touch -a test has just failed, so the subsequent
tests in this file will not be run.

In the output below, the date of last access for 'a' should
have been $u1.
EOF
   ls --full -lu a
  Exit 77
  ;;
esac

set $( ls -t a b c)
test "$*" = 'a b c' && : || fail=1
test $fail = 1 &&  ls -l --full-time a b c



Exit $fail

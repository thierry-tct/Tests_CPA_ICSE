#!/usr/bin/perl

# Copyright (C) 1998-2012 Free Software Foundation, Inc.

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

use strict;

(my $ME = $0) =~ s|.*/||;
my $prog = 'ls';

# Turn off localization of executable's output.
@ENV{qw(LANGUAGE LANG LC_ALL)} = ('C') x 3;

my $saved_ls_colors;

sub push_ls_colors($)
{
  $saved_ls_colors = $ENV{LS_COLORS} || '';
  $ENV{LS_COLORS} = $_[0];
}

sub restore_ls_colors()
{
  $ENV{LS_COLORS} = $saved_ls_colors;
}

# If the string $S is a well-behaved file name, simply return it.
# If it contains white space, quotes, etc., quote it, and return the new string.
sub shell_quote($)
{
  my ($s) = @_;
  if ($s =~ m![^\w+/.,-]!)
    {
      # Convert each single quote to '\''
      $s =~ s/\'/\'\\\'\'/g;
      # Then single quote the string.
      $s = "'$s'";
    }
  return $s;
}

# Set up files used by the setuid-etc tests; skip this entire test if
# that cannot be done.
sub setuid_setup()
{
  my $test = shell_quote "$ENV{abs_top_builddir}/src/test";
  system (qq(touch setuid && chmod u+s setuid && $test -u setuid &&
           touch setgid && chmod g+s setgid && $test -g setgid &&
           mkdir sticky && chmod +t sticky  && $test -k sticky &&
           mkdir owt    && chmod +t,o+w owt && $test -k owt &&
           mkdir owr    && chmod o+w owr)) == 0
             or CuSkip::skip "$ME: cannot create setuid/setgid/sticky files,"
                 . "so can't run this test\n";
}

sub mk_file(@)
{
  foreach my $f (@_)
    {
      open (F, '>', $f) && close F
        or die "creating $f: $!\n";
    }
}

sub mkdir_d {mkdir 'd',0755 or die "d: $!\n"}
sub rmdir_d {rmdir 'd'      or die "d: $!\n"}
my $mkdir = {PRE => sub {mkdir_d}};
my $rmdir = {POST => sub {rmdir_d}};
my $mkdir_reg = {PRE => sub {mkdir_d; mk_file 'd/f' }};
my $rmdir_reg = {POST => sub {unlink 'd/f' or die "d/f: $!\n";
                              rmdir 'd' or die "d: $!\n"}};

my $mkdir2 = {PRE => sub {mkdir 'd',0755 or die "d: $!\n";
                          mkdir 'd/e',0755 or die "d/e: $!\n" }};
my $rmdir2 = {POST => sub {rmdir 'd/e' or die "d/e: $!\n";
                           rmdir 'd' or die "d: $!\n" }};

my $target = {PRE => sub {
                mkdir 'd',0755 or die "d: $!\n";
                symlink '.', 'd/X' or die "d/X: $!\n";
                push_ls_colors('ln=target')
              }};
my $target2 = {POST => sub {unlink 'd/X' or die "d/X: $!\n";
                            rmdir 'd' or die "d: $!\n";
                            restore_ls_colors
                            }};
my $slink_d = {PRE => sub {symlink '/', 'd' or die "d: $!\n";
                           push_ls_colors('ln=01;36:di=01;34:or=40;31;01')
                           }};
my $unlink_d = {POST => sub {unlink 'd' or die "d: $!\n"; restore_ls_colors}};

my $mkdir_d_slink = {PRE => sub {mkdir 'd',0755 or die "d: $!\n";
                                 symlink '/', 'd/s' or die "d/s: $!\n" }};
my $rmdir_d_slink = {POST => sub {unlink 'd/s' or die "d/s: $!\n";
                                  rmdir 'd' or die "d: $!\n" }};

sub make_j_d ()
{
  mkdir 'j', 0700 or die "creating j: $!\n";
  mk_file 'j/d';
  chmod 0555, 'j/d' or die "making j/d executable: $!\n";
}

my @v1 = (qw(0 9 A Z a z), 'zz~', 'zz', 'zz.~1~', 'zz.0');
my @v_files = ((map { ".$_" } @v1), @v1);
my $exe_in_subdir = {PRE => sub { make_j_d (); push_ls_colors('ex=01;32') }};
my $remove_j = {POST => sub {unlink 'j/d' or die "j/d: $!\n";
                             rmdir 'j' or die "j: $!\n";
                             restore_ls_colors }};

my $e = "\e[0m";
my $q_bell = {IN => {"q\a" => ''}};
my @Tests =
    (
     ['sl-dangle4', '-o --time-style=+:TIME: --color=always l',
      {OUT_SUBST => 's/.*:TIME: //'},
      {OUT => "$e\e[36ml$e -> \e[35mnowhere$e\n"},
      {PRE => sub {symlink 'nowhere', 'l' or die "l: $!\n";
                   push_ls_colors('ln=34:mi=35:or=36:')
       }},
      {POST => sub {unlink 'l' or die "l: $!\n";
                    restore_ls_colors; }},
     ],
    );

umask 022;

# Start with an unset LS_COLORS environment variable.
delete $ENV{LS_COLORS};

my $save_temps = $ENV{SAVE_TEMPS};
my $verbose = $ENV{VERBOSE};

setuid_setup;
my $fail = run_tests ($ME, $prog, \@Tests, $save_temps, $verbose);
$fail
  and exit 1;


exit $fail;

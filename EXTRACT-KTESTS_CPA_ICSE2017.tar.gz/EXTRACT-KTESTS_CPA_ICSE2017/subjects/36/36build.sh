#!/bin/bash
# Build script for (1) rm
#Note: Make sure that here, all used tool are refered with absolute path (to avoid a control command to be considered as a test)
set -u
error_exit()
{
    /bin/echo $1
    exit 1
}

[ $# = 3 ] || error_exit "Error: build script expected 3 parameters, $# provided: <$0> <compiler> <CFLAGS> <mode: [ build(make distclean,bootstrap, config, make); clean-make(make clean, make); make]>"
COMPILER=$1
CFLAGS=$2
MODE=$3
rootDir=$MFI_ROOTDIR

calldir=`/bin/pwd`
cd $rootDir

/bin/rm -f $MFI_EXEDIR/$MFI_PROGRAM

testsdir="find/testsuite"

if [ "$MODE" = "build" ]
then
    #./import-gnulib.sh   # uncomment this if there are make errors
    make clean ; rm find/*.gcno; 
    if ! make distclean; then 
	#patching some problem
        export DO_NOT_WANT_CHANGELOG_DRIVER=1
        #patching old automake de-ANSI-fication problem
        sed -i.bak 's/AM_C_PROTOTYPES/dnl AM_C_PROTOTYPES/g' configure.ac
        sed -i.bak 's/AM_C_PROTOTYPES/dnl AM_C_PROTOTYPES/g' configure.in
        #rm -rf gnulib; 
        ./import-gnulib.sh gnulib-cvs/gnulib; autoreconf -i --force; 
    fi
    ./configure --disable-nls CC=$COMPILER CFLAGS="-Wno-error -std=c99 $CFLAGS" #|| error_exit "Error: configure failed. (in $0)"
    if [ $? != 0 ]
    then 
        make clean ; make distclean; #sleep 10
        ./import-gnulib.sh && autoreconf -i --force || error_exit "Error: import-gnulib.sh failed. (in $0)"
#        patch -f -d lib < $(dirname $0)/getdate.patch || patch -f -d gnulib/lib < $(dirname $0)/getdate.patch || error_exit "Error: patch getdate failed. (in $0)" 
        ./configure --disable-nls CC=$COMPILER CFLAGS="-Wno-error -std=c99 $CFLAGS" || error_exit "Error: configure failed. (in $0)"
    fi
    echo "all: ;" > doc/Makefile
    echo "all: ;" > po/Makefile
    make CC=$COMPILER CFLAGS="-Wno-error -std=c99 $CFLAGS" #|| error_exit "Error: make failed. (in $0)"
    # For tests suite
    cd $testsdir
    rm -rf tmp || error_exit "Error: Failed to remove $testsdir/tmp. (in $0)"
    make check-DEJAGNU RUNTESTFLAGS=access.exp #timeout 2s make check 
    test -d tmp && chmod 777 tmp && rm -rf 'tmp' ',' ')' '(1' '!2'
    test -f site.exp && echo 'set OPTIMISATION_LEVELS {0 1 2 3}' >> site.exp || error_exit "Error: Failed to 'patch' site.exp. (in $0)"
    cd -
elif [ "$MODE" = "clean-make" ]
then
    make clean;  rm find/*.gcno #|| error_exit "Error: make clean failed. (clean-make in $0)"
    make CC=$COMPILER CFLAGS="-Wno-error -std=c99 $CFLAGS" #|| error_exit "Error: make failed. (in $0)"
    cd $testsdir
    test -d tmp && chmod 777 tmp && rm -rf tmp 
    make check-DEJAGNU RUNTESTFLAGS=comma.exp #make check 
    test -d tmp && chmod 777 tmp && rm -rf tmp
    test -f site.exp && echo 'set OPTIMISATION_LEVELS {0 1 2 3}' >> site.exp || error_exit "Error: Failed to 'patch' site.exp. (in $0)"
    cd -
elif [ "$MODE" = "make" ]
then
    make CC=$COMPILER CFLAGS="-Wno-error -std=c99 $CFLAGS" #-std=gnu99 || error_exit "Error: make failed. (in $0)"
else
    error_exit "Error: Wrong build mode: $MODE. (in $0)"
fi

cd $calldir
echo Done
# *** wllvm can't generate BC when the extension is not .o, .so,...
### $COMPILER $CFLAGS -c `dirname $0`/src/main.c -o `dirname $0`/src/main.o	#Compile	

### $COMPILER $CFLAGS -o `dirname $0`/src/mainT `dirname $0`/src/main.o	#link


#! /bin/bash
versiondir=$(readlink -f $1)

TDIR=`mktemp -d`
cd $TDIR

printf "TARGETS = mbr.b\n.PHONY: all clean\n.SUFFIXES: .src .b\nall: \$(TARGETS)\nclean:\$(RM) \$(TARGETS)\nmbr.b: mbr.src\n\tcp \$*.src \$@\nmbr.src: ; @:\n" > Makefile

fail=0
touch mbr.src
$versiondir/make --just-print > out 2>&1 || fail=1
#echo "cp mbr.src mbr.b" > exp

#diff out exp || fail=1

cd -

exit $fail

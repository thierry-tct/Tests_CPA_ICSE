#!/usr/bin/perl
# Test "seq".

# Copyright (C) 1999-2012 Free Software Foundation, Inc.

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

use strict;

(my $program_name = $0) =~ s|.*/||;

# Turn off localization of executable's output.
@ENV{qw(LANGUAGE LANG LC_ALL)} = ('C') x 3;

my $prog = 'seq';
my $try_help = "Try '$prog --help' for more information.\n";

my $locale = $ENV{LOCALE_FR_UTF8};
! defined $locale || $locale eq 'none'
  and $locale = 'C';

my $p = '9' x 81;
(my $q = $p) =~ s/9/0/g;
$q = "1$q";
(my $r = $q) =~ s/0$/1/;

my @Tests =
  (
      ['fmt-7',	qw(-f %0+3.0f 1 2),   {OUT => [qw(+01 +02)]}],
  );

# Append a newline to each entry in the OUT array.
my $t;
foreach $t (@Tests)
  {
    my $e;
    foreach $e (@$t)
      {
        $e->{OUT} = join ("\n", @{$e->{OUT}}) . "\n"
          if ref $e eq 'HASH' and exists $e->{OUT};
      }
  }

my $save_temps = $ENV{SAVE_TEMPS};
my $verbose = $ENV{VERBOSE};

my $fail = run_tests ($program_name, $prog, \@Tests, $save_temps, $verbose);
exit $fail;

#! /bin/bash

## This script set up the project to run the tests, it also restore as initial.

error_exit()
{
    echo "setup_revert failure: $1"
    exit 1
}

[ $# = 2 ] || error_exit "Expected 2 arguments, $# passed.  $0 <mode [setup, revert]> <rootdir>"

mode=$1
rootDir=$2

TopDir=$(readlink -f $(dirname $0))

if [ "$mode" = "setup" ]
then
    if ! test -d $rootDir/tests.bak.bak
    then
        { test -d $rootDir/tests && mv $rootDir/tests $rootDir/tests.bak.bak ; } || error_exit "failed to backup tests"
    fi
    rm -rf $rootDir/tests
    cp -rf $TopDir/testscripts/tests $rootDir || error_exit "failed to copy physical tests scripts"
    cp --preserve -f $rootDir/tests.bak.bak/Makefile $rootDir/tests/Makefile || error_exit "cp makefile"
    cp --preserve -f $rootDir/tests.bak.bak/Makefile.in $rootDir/tests/Makefile.in || error_exit "cp makefile.in"
    cp --preserve -f $rootDir/tests.bak.bak/Makefile.am $rootDir/tests/Makefile.am || error_exit "cp makefile.am"
elif [ "$mode" = "revert" ]
then
    if test -d $rootDir/tests.bak.bak
    then
        rm -rf $rootDir/tests || error_exit "failed to removed physical tests scripts"
        mv $rootDir/tests.bak.bak $rootDir/tests || error_exit "Failed to restore tests"
    fi
else
    error_exit "Invalid mode"
fi

# from the rootdir. No need to used mfi optimization

set -u
error_exit()
{
	/bin/echo $1
	exit 3
}

[ $# = 1 ] || error_exit "Error: runtests script expects 1 paramter, $# provided: <$0> <test name>"
#make check-regression MAKETESTFLAGS=<path to test file(from inside 'tests/scripts')>
TC=$1

/usr/bin/test -f $MFI_EXEDIR/$MFI_PROGRAM || error_exit "Error: Could not find executable $MFI_PROGRAM."
rootDir=$MFI_ROOTDIR

if /bin/echo $TC | /bin/grep '\*\*MFI\*\*OPTIMIZE\*\*' > /dev/null
then
	#Do not need optimization
	exit 1
fi

 [ "${EKLEEPSE_RUN_COUNTER_FILE:-}" != "" ] && echo "$TC" | grep "^manuallyAddedMFI" > /dev/null && exit 0

cd $rootDir/tests
if echo "$TC" | grep "^manuallyAddedMFI/\|^regression/regression" > /dev/null; then scripts/$TC $MFI_EXEDIR/  > /dev/null; exit $?; fi 

TCSeq=""
realTC="$TC"
echo $TC | grep ".splittest[0-9]\+$" > /dev/null && { TCSeq="${TC#*.splittest}"; realTC="${TC%.splittest*}"; }

[ "${EKLEEPSE_REPLAY_TIMEOUT:-}" != "" ] && [ $EKLEEPSE_REPLAY_TIMEOUT -gt 5 ] && export EKLEEPSE_REPLAY_TIMEOUT=5

for ftrm in `ls | grep -v "^ChangeLog$\|^COPYING$\|^guile.supp$\|^mkshadow$\|^NEWS$\|^README$\|^run_make_tests$\|^run_make_tests.pl$\|^scripts$\|^test_driver.pl$" `
do
   rm -rf ./$ftrm || error_exit "Error: Failed to clean to avoid unwanted failures(as interupted test leave file and next fail when can't recreate)."
done

fail=0
OPTMAKEMFI__TCSeq=$TCSeq perl ./run_make_tests.pl -make $MFI_EXEDIR/make "$realTC" 2>&1 | grep "\.\.\.\. ok     (" > /dev/null 2>&1 || fail=1
#OPTMAKEMFI__TCSeq=$TCSeq make check-regression MAKETESTFLAGS="$realTC" | grep "\.\.\.\. ok     (" > /dev/null || fail=1

exit $fail

#`echo $ENV{"EKLEEPSE_REPLAY_MODE"} ... $ENV{"EKLEEPSE_REPLAY_KTEST"} >> ~/aaaa`;

#! /bin/bash

## This script set up the project to run the tests, it also restore as initial.

error_exit()
{
    echo "setup_revert failure: $1"
    exit 1
}

[ $# = 2 ] || error_exit "Expected 2 arguments, $# passed.  $0 <mode [setup, revert]> <rootdir>"

mode=$1
rootDir=$2

TopDir=$(readlink -f $(dirname $0))

if [ "$mode" = "setup" ]
then
    if ! test -d $rootDir/find/testsuite.bak.bak
    then
        { test -d $rootDir/find/testsuite && mv $rootDir/find/testsuite $rootDir/find/testsuite.bak.bak ; } || error_exit "failed to backup find/testsuite"
    fi
    rm -rf $rootDir/find/testsuite
    cp -rf $TopDir/testscripts/testsuite $rootDir/find || error_exit "failed to copy physical tests scripts"
    
    cd $rootDir/find/testsuite
    if test -d tmp; then
        chmod 777 tmp
        rm -rf tmp || error_exit "Error: Failed to remove $rootDir/find/testsuite/tmp. (in $0)"
    fi
    make check-DEJAGNU RUNTESTFLAGS=access.exp #timeout 2s make check 
    test -d tmp && chmod 777 tmp && rm -rf 'tmp' ',' ')' '(1' '!2'
    test -f site.exp && echo 'set OPTIMISATION_LEVELS {0 1 2 3}' >> site.exp || error_exit "Error: Failed to 'patch' site.exp. (in $0)"
    cd - > /dev/null
elif [ "$mode" = "revert" ]
then
    if test -d $rootDir/find/testsuite.bak.bak
    then
        rm -rf $rootDir/find/testsuite || error_exit "failed to removed physical tests scripts"
        mv $rootDir/find/testsuite.bak.bak $rootDir/find/testsuite || error_exit "Failed to restore find/testsuite"
    fi
else
    error_exit "Invalid mode"
fi

#! /bin/bash

set -u
set -o pipefail

error_exit()
{
    /bin/echo '@ktest-replayer.sh >> '$1
    type -t substitute_wrapper_with_tool > /dev/null && substitute_wrapper_with_tool 
    type -t cleanup_processes > /dev/null && cleanup_processes
    exit 1
}

if [ $# = 5 ]
then
    EMODE=$1
    KTESTSLOCDIR=$2
    KTS_FILE=$3
    TCS_FILE=$4
    OptimizerLog=$5
else
    error_exit "Param Error: expected 4 arguments, $# passed. args should be either 'oldnew' <KtestsDir> <ktestlist> <testlist>"
fi


TOOL=$MFI_PROGRAM
TOOL_DIR="$MFI_EXEDIR"

TOP_DIR=`/usr/bin/dirname $0`
/bin/echo "$TOP_DIR" | /bin/grep "^/" > /dev/null || TOP_DIR=`/bin/pwd`"/"$TOP_DIR

TOOL_DIRBUILD=$MFI_BUILD_FOLDER
TOOL_OLD=$MFI_BUILD_SUBFOLDER_OLD/$TOOL
TOOL_NEW=$MFI_BUILD_SUBFOLDER_NEW/$TOOL
TOOL_COMMON=$TOOL_DIRBUILD/$TOOL

term_signal_handler() {
  /bin/echo "Caught term signal" 
  substitute_wrapper_with_tool
  cleanup_processes
  exit 1
}

int_signal_handler() {
  /bin/echo "Caught int signal"
  substitute_wrapper_with_tool
  cleanup_processes
  exit 1
}

# since we use setsid we need to handle signals to properly terminate processes
# running in a separate session
trap term_signal_handler TERM 
trap int_signal_handler INT


export EKLEEPSE_REPLAY_COUNTER_FILE="$KTESTSLOCDIR/ekleepse_replay_counter"
sudo /bin/rm -f $EKLEEPSE_REPLAY_COUNTER_FILE $EKLEEPSE_REPLAY_COUNTER_FILE.lock
/usr/bin/touch $EKLEEPSE_REPLAY_COUNTER_FILE $EKLEEPSE_REPLAY_COUNTER_FILE.lock
/bin/chmod 666 $EKLEEPSE_REPLAY_COUNTER_FILE $EKLEEPSE_REPLAY_COUNTER_FILE.lock   # this because any test should be able to read/write this file, and some test create new user without priviledge to write the file...

REPLAY_ERR_STR="klee-replay: error"
REPLAY_ERR_STR2="klee-replay: EXIT STATUS: ABNORMAL 1"

cleanup_processes() {
  sid=`/usr/bin/head -n 1 $MFI_ROOTDIR/ekleepse_sid > /dev/null 2>&1`            #TODO: "> /dev/null 2>&1 " 
  mysid=`/bin/ps xao pid,sid | /usr/bin/awk -v pid=$$ '{ if ($1 == pid) print $2}'`
  ##/bin/echo "Will cleanup processes belonging to sid $sid, mysid is $mysid"

  # find all processes belonging to the session
  session_pids=`/bin/ps xao pid,sid | /usr/bin/awk -v s=$sid '{ if ($2 == s) print $1}'`

  for p in $session_pids
  do
    if /bin/ps -p "$p" > /dev/null
    then
      /bin/kill -STOP $p
      /bin/sleep 0.5
      /bin/kill $p
      /bin/sleep 0.5
      while /bin/kill -0 "$p"; do
        /bin/sleep 0.5
        /bin/kill -9 $p
      done
    fi
  done

  ##/bin/echo "Processes for the session are: $session_pids"
  # just in case more processes were spawned in the meantime :)
  while [ -n "$session_pids" ]; do 
    /usr/bin/pkill -s $sid --signal 9
    /bin/sleep 1
    session_pids=`/bin/ps xao pid,sid | /usr/bin/awk -v s=$sid '{ if ($2 == s) print $1}'`
  ##  /bin/echo "Processes for the session are: $session_pids" 
  done

  ##/bin/echo "Cleanup complete"
}

run_old_and_new() {

  # first, the old version
  /bin/cp -f $TOOL_OLD $TOOL_COMMON || error_exit "Error: Failed to copy $TOOL_OLD into $TOOL_COMMON. (in $0))"
  
  export EKLEEPSE_REPLAY_TOOL=$TOOL_COMMON
  export EKLEEPSE_REPLAY_KTEST=$tc_dir/$t
  
  args=$argv
  export EKLEEPSE_RUN_ARGS=$args
  
  # MFI: replay old 
  export EKLEEPSE_REPLAY_LOG=$old_replay_log
  export EKLEEPSE_REPLAY_ATTEMPT="$replay_attempt.old"
  /bin/rm -f "$replay_attempt.old"
  
  reset_test_suite_counters

  ## /bin/echo -n "" > $EKLEEPSE_PROCESS_LIST_FILE
  
  #/bin/echo "running with original args $args"
  
  /bin/echo "$exec_number" > $EKLEEPSE_REPLAY_COUNTER_FILE || error_exit "Error: Failled to set replay counter"
  /bin/chmod 666 $EKLEEPSE_REPLAY_COUNTER_FILE $EKLEEPSE_REPLAY_COUNTER_FILE.lock
  
  #run on Old version
  #/usr/bin/setsid
   $MFI_RUNTESTSCRIPT $test_case 
  [ $? = 3 ] && error_exit "Error: $MFI_RUNTESTSCRIPT failed (in $0:run_old_new -- Old)"	

  cleanup_processes 
  ##  /bin/echo -n "" > $EKLEEPSE_PROCESS_LIST_FILE
  
  ## Mid time
  GLOBALtmidrun=$SECONDS
  
  # MFI: replay new only if log not present (not yet collected oracles)
  if [ ! -f $new_replay_log ]
  then
      export EKLEEPSE_REPLAY_LOG=$new_replay_log
      export EKLEEPSE_REPLAY_ATTEMPT="$replay_attempt.new"
      /bin/rm -f "$replay_attempt.new" $new_replay_log

      reset_test_suite_counters

      # now, the new version
      # note, we use the same path for the tool to avoid spurious diffs
      /bin/cp -f $TOOL_NEW $TOOL_COMMON

      /bin/echo "$exec_number" > $EKLEEPSE_REPLAY_COUNTER_FILE || error_exit "Error: Failled to set replay counter"
      /bin/chmod 666 $EKLEEPSE_REPLAY_COUNTER_FILE $EKLEEPSE_REPLAY_COUNTER_FILE.lock

      #/Run on new version 
      #/usr/bin/setsid 
      $MFI_RUNTESTSCRIPT $test_case 
      [ $? = 3 ] && error_exit "Error: $MFI_RUNTESTSCRIPT failed (in $0:run_old_new -- New)"       #TODO TCT

      cleanup_processes 
  fi
  ## /bin/echo -n "" > $EKLEEPSE_PROCESS_LIST_FILE
}


setup_test_suite_counters() {
  # make test run and replay more repeatable by using a seeded counter file rather
  # than PIDs (will only be effective for these revisions that applied the
  # necessary test suite patches: e.g. for other-fs-tmpdir) 
  export TEST_SUITE_COUNTER_FILE=$KTESTSLOCDIR/ekleepse_test_suite_counter
  export TEST_SUITE_FILES=$KTESTSLOCDIR/ekleepse_test_suite_files

  reset_test_suite_counters 
}

reset_test_suite_counters() {
  # start counting from a seed value, which is unique for each revision and stored
  # in seedfile that should have been copied by the build-me script
  /bin/echo 0 > $TEST_SUITE_COUNTER_FILE		# set the counter seed to 0 by default
}

substitute_tool_with_wrapper() {
  TOOL_PATH="$TOOL_DIR/$TOOL"

  WRAPPER="$TOOL_PATH.replay_wrapper"
 
  #echo "Substituting $TOOL_PATH for $WRAPPER"
  /usr/bin/touch -r $TOOL_PATH $WRAPPER $TOOL_PATH.native   # This makes sure that the wrapper has same time stamp with TOOL, therefore will not be updated by make-check
  /bin/cp --preserve -f $WRAPPER $TOOL_PATH || error_exit "Error:$0: Failed to copy wrapper to tool"
}

substitute_wrapper_with_tool() {
  TOOL_PATH="$TOOL_DIR/$TOOL"
  #/bin/echo "Substituting wrapped $TOOL_PATH for native"  
  /bin/cp --preserve -f $TOOL_PATH.native $TOOL_PATH || error_exit "Error:$0: Failed to copy tool to wrapper"
}

process_test_cases() 
{

    [[ "$#" -eq 1 ]] || error_exit "process_test_cases() takes 1 argument: cov, newold"

    mode=$1

    setup_test_suite_counters

    cd $TOP_DIR

    current_dir=`/bin/pwd`

    # first get all the test cases of interest from the file
    test_cases=$(/usr/bin/tr '\n' ' ' <$TCS_FILE)

    #/bin/echo "test_cases are: $test_cases"
    
    numKTComplete=0
    
    #while read test_case
    for test_case in $test_cases
    do
       
        # transform test case name to results directory name
        tc_results_dir_name=$(/bin/echo "$test_case" | /usr/bin/tr '/' '_')
          
        ktests=($(/bin/cat $KTS_FILE| /bin/grep "^$tc_results_dir_name-out"))

        if [ "${#ktests[@]}" = 0 ]; then 
          #echo "results directory does not exists - continuing"
            continue 
        fi
          
        for ktest in "${ktests[@]}"
        do
            /usr/bin/test -f $KTESTSLOCDIR/$ktest || error_exit "Error: KTEST $ktest not found in $KTESTSLOCDIR (in $0)"
            
            [ "${GLOBALlogReplayintoThis:-}" = "/dev/null" ] || /bin/echo "$(/usr/bin/basename $0) >> replaying $ktest ..."
            exec_number=$(/usr/bin/basename $(/usr/bin/dirname $ktest) | /usr/bin/cut -d- -f3) 
            [ "$exec_number" != "" ] || error_exit "Error: Incorrect exec_number for ktest $ktest. (in $0)"
            
            if /usr/bin/basename $(/usr/bin/dirname $ktest) | /bin/grep "klee-" > /dev/null
            then
                export MFIKESTSREPLAY_NATIVEREPLAY=0
            else
                export MFIKESTSREPLAY_NATIVEREPLAY=1
            fi
            
            tc_dir="$KTESTSLOCDIR/$(/usr/bin/dirname $ktest)"
            TMP_REPLAY_LOG_FILE="$tc_dir/replay-out.newlog"
         
            local argv=`/bin/sed -n "/$TOOL.bc/,/PID/p" "$tc_dir/info" | /usr/bin/head -n-1 | /bin/sed "s/.*$TOOL.bc/$TOOL/"` || error_exit "Error: Failed to get argv ~~process_test_cases~~ (in $0)"

            export EKLEEPSE_REPLAY_ARGV="$argv"
            
            t=$(/usr/bin/basename $ktest)
            #echo "test: $t" >> /tmp/mylog
            base_file=$(/bin/echo "$t" | /bin/sed 's/\.ktest//')
            #echo "base_file is $base_file"

            export EKLEEPSE_REPLAY_MODE=0
            
            if [ -f $tc_dir/$base_file.ktimeout ]
            then
                mytmptimeout=$(/bin/cat $tc_dir/$base_file.ktimeout)
                [ $mytmptimeout -lt 1 ] && mytmptimeout=1
                export EKLEEPSE_REPLAY_TIMEOUT=$(($mytmptimeout < $EKLEEPSE_REPLAY_MAXTIMEOUT ? $mytmptimeout : $EKLEEPSE_REPLAY_MAXTIMEOUT))
            else
                export EKLEEPSE_REPLAY_TIMEOUT=$EKLEEPSE_REPLAY_MAXTIMEOUT
                tstart=$SECONDS
                GLOBALtmidrun=$SECONDS
            fi 
                
            if [ "$EMODE" = "oldnew" ]
            then 
                old_replay_log=$tc_dir/$base_file.old.newout
                new_replay_log=$tc_dir/$base_file.new.newout
                replay_diff_log=$tc_dir/$base_file.newdiff
                replay_error_flag=$tc_dir/$base_file.replay.newerr
                replay_attempt=$tc_dir/$base_file.replay.attempt 
                      
                /bin/rm -f $old_replay_log $replay_diff_log $replay_attempt.old $replay_error_flag || error_exit "Error: Failed to remove the existing 'old replay log' and diff"
                
                #newismutant=0
                #[ -f $old_replay_log ] && newismutant=1 
                
                #For very large logs (>= 1M)
                [ -f $new_replay_log -a ! -s $new_replay_log ] && /bin/rm -f $new_replay_log  #Empty mean was too big (replay to get real log.). Note that this is not needed for old, as alway replayed
                
                run_old_and_new
                if [ "${GLOBALlogReplayintoThis:-}" != "/dev/null" ] 
                then
                    numKTComplete=$(($numKTComplete + 1))
                    /bin/echo ">> ($numKTComplete) FInished ktests $ktest "
                fi
                
                [ -f $tc_dir/$base_file.ktimeout ] || /bin/echo "$(( ($SECONDS - $tstart)/2 + ($SECONDS - $GLOBALtmidrun)/2 ))" > $tc_dir/$base_file.ktimeout
                
                #if [ $MFI_ID != 1 -a $MFI_ID != 6 -a $MFI_ID != 12 ]; then  #TODO remove echo bellow, uncomment error_exit
                /usr/bin/test -f $old_replay_log || echo "OLD:$ktest" >> $(dirname $OptimizerLog)/NoLog # || error_exit "Debug: no old log. KTESTS: $ktest"; # newisMutant: $newismutant."; 
                /usr/bin/test -f $new_replay_log || echo "NEW:$ktest" >> $(dirname $OptimizerLog)/NoLog # || error_exit "Debug: no new log. KTESTS: $ktest"; # newisMutant: $newismutant."; 
                #fi
                
                # This actually always true because of /usr/bin/test above
                if [[ ! -f $old_replay_log && ! -f $new_replay_log ]]; then
                    /bin/echo "$t" >> $TMP_REPLAY_LOG_FILE
                    /usr/bin/touch $replay_error_flag
                    continue
                fi
                            
                /usr/bin/diff -N -q $old_replay_log $new_replay_log > $replay_diff_log  # Do not insert instruction right after this (watch the $? bellow)
                if [[ $? -eq 0 ]]; then
                    /bin/rm -f $replay_diff_log
                else
                    #For very large logs (>= 1M)
                    [ `/usr/bin/stat -c "%s" $replay_diff_log` -gt 1048576 ] && /bin/echo 'MFI: Very large log diff(>=1M) detected. replaced by this.' > $replay_diff_log
                fi
                
                #For very large logs (>= 1M)
                [ -f $old_replay_log -a `/usr/bin/stat -c "%s" $old_replay_log` -gt 1048576 ] && /bin/echo -n "" > $old_replay_log  #Empty mean was too big (klee-replay alway put some data..)
                [ -f $new_replay_log -a `/usr/bin/stat -c "%s" $new_replay_log` -gt 1048576 ] && /bin/echo -n "" > $new_replay_log  #Empty mean was too big (klee-replay alway put some data..)
                
                #[ $newismutant = 1 ] && /bin/rm -f $new_replay_log
            else
                error_exit "Invalid mode for ktest-replay"
            fi
        done
    done
}

#xxxxx=`sed '1 q;d' $KTS_FILE`
#echo $xxxxx > $KTS_FILE

if [ "$EMODE" = "oldnew" ] 
then
    export EKLEEPSE_REPLAY_MAXTIMEOUT="${MFIKTESTSREPLAY_USER_SET_MAXTIMEOUT:-60}"  #MFIKTESTSREPLAY_USER_SET_MAXTIMEOUT can be set in the optimizer(project's runtest script)

    GLOBALlogReplayintoThis=$OptimizerLog #/dev/null #"$MFI_OUTPUTDIR/mfiReplayLog.tmp.log"   #/dev/null #
    ##[ "$MFI_ID" = "5" ] && GLOBALlogReplayintoThis="$MFI_OUTPUTDIR/mfiReplayLog.tmp.log"
    #[ "$EMODE" = "frama-c_WM" ] && GLOBALlogReplayintoThis="$MFI_OUTPUTDIR/mfiReplayLog.tmp.log"
    
    #Optimiser
    if [ "${MFIOPT_KTESTSREPLAY_OPTIMIZER:-off}" = "off" ]
    then
        /bin/echo "$(/bin/date '+%Y-%m-%d %H:%M:%S')# Ktests replaying '$EMODE' (log: $GLOBALlogReplayintoThis)..."
        export MFIOPT_KTESTSREPLAY_OPTIMIZER="on"
        optParame="$EMODE $KTESTSLOCDIR $KTS_FILE $TCS_FILE $OptimizerLog"
        #[ "$EMODE" = "frama-c_WM" ] && optParame+=" $TOOL_WM_LABELED_wm $MUTANT_SOURCES_wm $WM_OUT_wm $WEAK_MUT_DAT_wm"
        #/usr/bin/setsid
        $MFI_RUNTESTSCRIPT "**MFI**OPTIMIZE**$TOP_DIR/$(/usr/bin/basename $0) $optParame > $GLOBALlogReplayintoThis 2>&1; exit \$?;" 
        optRetCode=$?
        /bin/echo "Optimizer returned $optRetCode." | /usr/bin/tee -a $GLOBALlogReplayintoThis
        if [ $optRetCode = 255 ]
        then
            [ "$GLOBALlogReplayintoThis" != "/dev/null" ] && /bin/rm -f $GLOBALlogReplayintoThis
            exit 0
        elif [ $optRetCode = 254 ]
        then
            error_exit "Error During execution of optimized ktests replay. view: $GLOBALlogReplayintoThis"
        fi
        export MFIOPT_KTESTSREPLAY_OPTIMIZER="off"
    fi
  
    /bin/echo "KTEST_REPLAY: starting replay ($EMODE) ..."
    #sudo /bin/chmod -R 777 "$TOOL_DIR" || error_exit "Error: Failed to change $TOOL_DIR access mode to 777. (in $0)"
    substitute_tool_with_wrapper
    process_test_cases "$EMODE"
    substitute_wrapper_with_tool
    
    [ "${MFIOPT_KTESTSREPLAY_OPTIMIZER:-off}" = "off" ] && [ "$GLOBALlogReplayintoThis" != "/dev/null" ] && /bin/rm -f $GLOBALlogReplayintoThis
    /bin/echo "KTEST_REPLAY: Finished replaying ($EMODE)."
else
    error_exit "Error: Unsuported mode '$EMODE'. (in $0)"
fi

exit 0


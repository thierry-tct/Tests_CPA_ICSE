#! /bin/bash

# This script run tests. arguments:
# $1: bug ID of the correspomding subject
# $2: the rootdir of the repository of the subject
# $3: the mode ('tests', to run everything; 'revert' to only revert the repo, in case for example of crach of this script)
# $4: optional filename of list of text to run

set -u
set -o pipefail

error_exit()
{
    echo "@ run.sh failed: $1"
    
    local myID=$$   # get P's PID (ran in P)
    local pl=$(/usr/bin/pstree -p -a -l $myID | /usr/bin/cut -d, -f2 | /usr/bin/cut -d, -f2 | cut -d' ' -f1 |  /usr/bin/xargs | /usr/bin/cut -d' ' -f2-)  # get the list of sub-processes (sorted from parents to children)
    pl=$(/bin/echo $pl | tr ' ' '\n' | /usr/bin/tac)  #tac help reversing the order so that child process is killed first...
    /bin/kill -9 $pl   # kill all the children
    
    exit 1
}

[ $# = 3 ] || [ $# = 4 ] || error_exit "expected 3 or 4 arguments, $# passed. [$0 <bug ID> <repo rootDir> <mode(tests, revert)> ?<ktestList>]"

TopDir=$(dirname $(readlink -f $0))

bugID=$1
repoRootDir=$(readlink -f $2)
mode=$3
workDir=$TopDir/subjects/$bugID

KtestList=$(readlink -f ${4:-$workDir/$bugID-ktestlist.txt})   # $4
physicalTestList=$workDir/$bugID-physTClist.txt

trap 'error_exit "$0 caught SIGTERM"' TERM 
trap 'error_exit "$0 caught SIGINT"' INT

AllgenKtest=$workDir/genktests
KtestPassFail=$workDir/test-verdict-output/"$bugID-ktestPassFail.txt"

optimizeLog=$workDir/test-verdict-output/OptimizetestExecutionLog.log

rm -rf $(dirname $optimizeLog)/NoLog

KEEP_NEW_OUT_FOR_FASTER_NEXT_EXECUTION=false

############## Functions
collect_diffs()
{
    local outfile=$1
    local considered_kt=$2
    rm -f $outfile || error_exit "Error: collect_diffs: failed to reset output file $outfile"
    # for each test, the value 0 mean 'pass' or mutant 'not killed', and the value 1 mean 'fail' or mutant 'killed'
    cd $AllgenKtest
    
    for ktest in `find . -type f -name "*.ktest" | sed 's|^\./||g'`
    do
        grep "$ktest" $considered_kt > /dev/null || continue
        
        test -f $(dirname $optimizeLog)/NoLog && grep $ktest $(dirname $optimizeLog)/NoLog > /dev/null && continue   #TODO
        
        echo -n "$ktest" >> $outfile
        
        [ -f ${ktest%.ktest}.new.newout ] || error_exit "Error: New log absent for fix version: $ktest (in collect_diffs)"
        [ -f ${ktest%.ktest}.old.newout ] || error_exit "Error: Old log absent for $ktest (in collect_diffs)"
        
        if [ -f ${ktest%.ktest}.newdiff ]
        then
            echo " 1" >> $outfile || error_exit "Error: Failed to write mutant run result (killed): (in $0)"
            rm -f ${ktest%.ktest}.newdiff || error_exit "Error: Failed to remove diff after collecting: (in $0)"
        else
            echo " 0" >> $outfile || error_exit "Error: Failed to write mutant run result (killed): (in $0)"
        fi
    done
    
    cd - > /dev/null
    #error_exit ""
}

clean_logs()
{
    rm -f $optimizeLog
    
    cd $AllgenKtest
    rm -f "ekleepse_replay_counter" "ekleepse_replay_counter.lock" "ekleepse_test_suite_counter" "ekleepse_test_suite_files"
    #for ktest in `find . -type f -name "*.ktest"`
    #do
    #    local prefkt=${ktest%.ktest}
    #    rm -f $prefkt.new.newout $prefkt.old.newout $prefkt.newdiff $prefkt.replay.attempt.old $prefkt.replay.attempt.new $prefkt.replay.newerr
    #    rm -f $(dirname $ktest)/replay-out.newlog
    #done
    for dirKT in `find . -type f -name "*.ktest" | xargs dirname | sort -u`
    do
        [ $KEEP_NEW_OUT_FOR_FASTER_NEXT_EXECUTION = false ] && rm -f $dirKT/*.new.newout
        rm -f $dirKT/*.old.newout $dirKT/*.newdiff $dirKT/*.replay.attempt.old $dirKT/*.replay.attempt.new $dirKT/*.replay.newerr $dirKT/*.ktimeout
        rm -f $dirKT/replay-out.newlog
    done
    find -type d -name "*.temps" -exec rm -rf {} +
    cd -> /dev/null
}

######### ~~ Functions ~~

#get parameters
cd $workDir
export MFI_BUILD_FOLDER=$workDir/build-versions
export MFI_BUILD_SUBFOLDER_OLD=$MFI_BUILD_FOLDER/old-version
export MFI_BUILD_SUBFOLDER_NEW=$MFI_BUILD_FOLDER/new-version
export MFI_ROOTDIR="$repoRootDir"
. $bugID\conf-script.conf

## In case the user forgot to revert afteer crash...    
/usr/bin/setsid $workDir/$bugID-setup_revert.sh "revert" $MFI_ROOTDIR  || error_exit "Revert initial failed for $bugID"
    
if [ "$mode" = "tests" ]
then
    mkdir -p $MFI_BUILD_SUBFOLDER_OLD $MFI_BUILD_SUBFOLDER_NEW || error_exit "Failed to create build-versions dirs for $bugID"

##### INTEGRATION HERE ####    
  #Compile Old and store exe
    $TopDir/corebenchBuild.sh $MFI_ID $MFI_ROOTDIR "OLD" || error_exit "Failed building old version"
    cp --preserve -f $MFI_EXEDIR/$MFI_PROGRAM $MFI_BUILD_SUBFOLDER_OLD || error_exit "Failed to copy OLD version's executable"
    
  #Compile New and store exe
    $TopDir/corebenchBuild.sh $MFI_ID $MFI_ROOTDIR "NEW" || error_exit "Failed building new version"
    cp --preserve -f $MFI_EXEDIR/$MFI_PROGRAM $MFI_BUILD_SUBFOLDER_NEW || error_exit "Failed to copy NEW version's executable"
#####   -------   ####
    
    test -f $MFI_BUILD_SUBFOLDER_OLD/$MFI_PROGRAM || error_exit "Old executable missing in Build subfolder"
    test -f $MFI_BUILD_SUBFOLDER_NEW/$MFI_PROGRAM || error_exit "New executable missing in Build subfolder"
    
  #SETUP
    echo "SETUP ..."
    /usr/bin/setsid $workDir/$bugID-setup_revert.sh "setup" $MFI_ROOTDIR || error_exit "Setup failed for $bugID"
    echo  "Setup ok."
    
  #Install Wrapper
    cp -f "$TopDir/wrapper-call-klee-replay.in" "$MFI_EXEDIR/$MFI_PROGRAM.replay_wrapper" || error_exit "fail to install wrapper for $bugID"
    sed -i'' "s|IN_TOOL_DIR|$MFI_EXEDIR|g; s|IN_TOOL_NAME|$MFI_PROGRAM|g" "$MFI_EXEDIR/$MFI_PROGRAM.replay_wrapper" || error_exit "fail to install wrapper (sed command) for $bugID"
    cp --preserve -f $MFI_EXEDIR/$MFI_PROGRAM $MFI_EXEDIR/$MFI_PROGRAM.native || error_exit "fail to install wrapper for $bugID"
    
  #Make sure we use klee-replay of klee shadow's version, which use llvm 2.7
     export PATH=$TopDir/klee-replay:$PATH
    
  #Run the tests
    clean_logs
    #chmod -R 777 $AllgenKtest || error_exit "Error: Failed to give any access to $AllgenKtest for test involving other users. (in $0)"
    #cp --preserve -R -f $AllgenKtest/* $MFI_EXEDIR || error_exit "Error: Failed to copy ktests for replay. (in $0)"
    
    rm -rf $(dirname $KtestPassFail) || error_exit "failed to remove previous test-verdict dir"
    mkdir -p $(dirname $KtestPassFail) || error_exit "failed to create test-verdict dir"
    
    echo "Test execution staring for ID: $bugID, test list: $KtestList"
    $TopDir/ktest-replayer.sh "oldnew" $AllgenKtest $KtestList $physicalTestList $optimizeLog || error_exit "Test execution failed for $bugID"
    
    echo "Collecting diffs.."
    collect_diffs $KtestPassFail $KtestList
    
    #clean_logs
elif [ "$mode" != "revert" ]
then
    error_exit "Invalid mode passed"
fi

#Uninstall wrapper
rm -f "$MFI_EXEDIR/$MFI_PROGRAM.replay_wrapper"
test -f $MFI_EXEDIR/$MFI_PROGRAM.native && cp --preserve -f $MFI_EXEDIR/$MFI_PROGRAM.native $MFI_EXEDIR/$MFI_PROGRAM

#REVERT
clean_logs
echo "REVERT ..."
/usr/bin/setsid $workDir/$bugID-setup_revert.sh "revert" $MFI_ROOTDIR || error_exit "Revert failed for $bugID"
rm -f $MFI_EXEDIR/$MFI_PROGRAM.native

echo "@ run.sh: Done!"

